# PCW|Integrates Smarthome System Development

## High-Level Setup Checklist
- [Prerequisites](#prerequisites)
- [Software Selection](#software-selection)
- [1Password Integration](#1password-integration)
- [Cosmos Cloud Setup](#cosmos-cloud-setup)
- [Home Assistant Setup](#home-assistant-setup)
- [Node-RED Integration](#node-red-integration)

... more sections ...
